package westmine;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import de.netzkronehd.wgregionevents.events.RegionEnterEvent;



public class Scanner implements Listener {
	public Westmine plugin;

	
	public Scanner(Westmine plugin){
	     this.plugin = plugin;
	}
	
	
	@EventHandler
	public void onRegionLeave(RegionEnterEvent e) {
	  if (!(e.getRegion().getId().contains("scanner"))) return;
	  Player p = e.getPlayer();
	  p.sendMessage("it works!");
	}
	
}


