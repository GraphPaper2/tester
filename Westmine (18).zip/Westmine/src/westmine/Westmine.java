package westmine;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import net.milkbowl.vault.economy.Economy;

public class Westmine extends JavaPlugin {
	
	final FileConfiguration config = this.getConfig();	
	public static Economy eco;    
    private static Westmine Instance;
	public Scoreboard abb;
    
	public HashMap<String, String> day = new HashMap<String, String>();
	public HashMap<UUID, Number> fitness = new HashMap<UUID, Number>();
	public HashMap<Player, Integer> cell = new HashMap<Player, Integer>();
	public HashMap<UUID, Integer> rep = new HashMap<UUID, Integer>();
	public HashMap<Player, FastBoard> boards = new HashMap<Player, FastBoard>();
    ArrayList<Location> cells = new ArrayList<Location>();


	
	@SuppressWarnings("unchecked")
	public void onEnable() {
		Instance = this;
		setInstance2(this);
	    if (!setupEconomy()) {
	    	System.out.println("Economy wasn't set up");
	    	return;
	    }
        getCommand("cellslist").setExecutor(new Cells(this));
        getCommand("clearcells").setExecutor(new Cells(this));
        getCommand("removecell").setExecutor(new Cells(this));
		this.getServer().getPluginManager().registerEvents(new Scanner(this),this);
		this.getServer().getPluginManager().registerEvents(new Scoreboard(this),this);
		this.getServer().getPluginManager().registerEvents(new Cells(this),this);
		abb = new Scoreboard(Instance);
	    getServer().getOnlinePlayers().forEach(player -> abb.createBoard(player));
	    if (!(getConfig().getList("cells") == null)) {
	    	cells.addAll((Collection<? extends Location>) getConfig().getList("cells"));
	    }
		@SuppressWarnings("unused")
		BukkitTask task = new BukkitRunnable() {
		    public void run() {
		    	updateScoreBoards();
		       
		    }
		}.runTaskTimer(this, 70L, 70L);
		



	}
	
	public void updateScoreBoards() {
        if (Bukkit.getOnlinePlayers().size() == 0) {
            return;
        } else {
            getServer().getOnlinePlayers().forEach(player -> abb.updateBoard(this.boards.get(player), player));
        }
    }
	

	
	public void onDisable() {
		saveConfig();
		
	}
	
	private boolean setupEconomy() {
		RegisteredServiceProvider<Economy> economy = getServer().getServicesManager().getRegistration(net.milkbowl.vault.economy.Economy.class);
		if (economy != null) {
			eco = economy.getProvider();
		}
		return (eco != null);
	}

	public static Westmine getInstance3() {
		return Instance;
	}

	public void setInstance2(Westmine instance) {
		Instance = instance;
	}
}

