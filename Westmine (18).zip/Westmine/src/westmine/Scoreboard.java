package westmine;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import eu.iamgio.hexchat.hexchat.HexText;
import net.milkbowl.vault.economy.Economy;

public class Scoreboard implements Listener {
	
	public Westmine plugin;
	
	private Economy eco = Westmine.eco;

	
    public Map<UUID, FastBoard> boards = new HashMap<>();
	
	
	public Scoreboard(Westmine plugin){
	     this.plugin = plugin;
	}
	
	public Scoreboard() {
	}
	

	@EventHandler
	public void OnJoin(PlayerJoinEvent e) {
		createBoard(e.getPlayer());
	}
	
	
	public void createBoard(Player p) {
	    String text1 = new HexText("      ").translateColorCodes().parseHex().toString();
	    String text2 = new HexText("             ").translateColorCodes().parseHex().toString();
	    String text3 = new HexText("").translateColorCodes().parseHex().toString();
	    String text4 = new HexText("    ┍━━━━━━━━━★━━━━━━━━┑").translateColorCodes().parseHex().toString();
	    String text5 = new HexText("    ︳ &#48635B&lDAY:&f " + plugin.day.get("")).translateColorCodes().parseHex().toString();
	    String text6 = new HexText("    ︳ &f&lBANK:&f " + eco.getBalance(p)).translateColorCodes().parseHex().toString();
	    String text7 = new HexText("    ︳ &#48635B&lREP:&f " + plugin.rep.get(p.getUniqueId())).translateColorCodes().parseHex().toString();
	    String text8 = new HexText("    ︳ &f&lCELL:&f " + plugin.cell.get(p)).translateColorCodes().parseHex().toString();
	    String text9 = new HexText("    ︳ &#48635B&lFITNESS: " + plugin.fitness.get(p.getUniqueId())).translateColorCodes().parseHex().toString();
	    String text10 = new HexText("    ┕━━━━━━━━━━━━━━━━━━━┙").translateColorCodes().parseHex().toString();
        FastBoard board = new FastBoard(p);
        board.updateTitle("" + text1);
        boards.put(p.getUniqueId(), board);
        board.updateLines(
        		"" + text2,
        		"" + text3,
        		"" + text4,
        		"" + text5,
        		"" + text6,
        		"" + text7,
        		"" + text8,
        		"" + text9,
        		"" + text10);
        if (!(plugin.boards.get(p) == null)) return;
        plugin.boards.put(p, board);
	}
	
    public void updateBoard(FastBoard board, Player p) {
    	Number fitness = null;
    	Integer rep = null;
    	if (plugin.fitness.get(p.getUniqueId()) == null) fitness = 0; else if (!(plugin.fitness.get(p.getUniqueId()) == null)) fitness = plugin.fitness.get(p.getUniqueId());
    	if (plugin.rep.get(p.getUniqueId()) == null) rep = 0; else if (!(plugin.rep.get(p.getUniqueId()) == null)) rep = plugin.rep.get(p.getUniqueId());
	    //String text1 = new HexText("      ").translateColorCodes().parseHex().toString();
	    String text1 = new HexText("             ").translateColorCodes().parseHex().toString();
	    String text2 = new HexText("").translateColorCodes().parseHex().toString();
	    String text3 = new HexText("    ┍━━━━━━━━━★━━━━━━━━┑").translateColorCodes().parseHex().toString();
	    String text4 = new HexText("    ︳ &#48635B&lDAY:&f " + plugin.day.get("")).translateColorCodes().parseHex().toString();
	    String text5 = new HexText("    ︳ &f&lBANK:&f " + eco.getBalance(p)).translateColorCodes().parseHex().toString();
	    String text6 = new HexText("    ︳ &#48635B&lREP:&f " + rep).translateColorCodes().parseHex().toString();
	    String text7 = new HexText("    ︳ &f&lCELL:&f " + plugin.cell.get(p)).translateColorCodes().parseHex().toString();
	    String text8 = new HexText("    ︳ &#48635B&lFITNESS: " + fitness).translateColorCodes().parseHex().toString();
	    String text9 = new HexText("    ┕━━━━━━━━━━━━━━━━━━━┙").translateColorCodes().parseHex().toString();
        board.updateLines(
        		"" + text1,
        		"" + text2,
        		"" + text3,
        		"" + text4,
        		"" + text5,
        		"" + text6,
        		"" + text7,
        		"" + text8,
        		"" + text9);
    }

}
