package westmine;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;


import net.milkbowl.vault.economy.Economy;

public class Cells implements Listener, CommandExecutor {
	public Westmine plugin;
	private Economy eco = Westmine.eco;
	private Inventory gui;
	public Cells(Westmine plugin){
	     this.plugin = plugin;
	}
	
	
	@EventHandler 
	public void addcell(PlayerInteractEvent e) {
		if (e.getClickedBlock() == null) return;
		if (!(e.getClickedBlock().getType().equals(Material.OAK_WALL_SIGN))) return;
		Location loc = e.getClickedBlock().getLocation();
		FileConfiguration config = this.plugin.getConfig();
		plugin.cells.add(loc);
		config.set("cells", plugin.cells);
		plugin.saveConfig(); 
		e.getPlayer().sendMessage("added!");
		//
		//
		
		
	}
	@EventHandler
	public void cell2(PlayerInteractEvent e) {
		if (e.getClickedBlock() == null) return;
		if (!(e.getClickedBlock().getType().equals(Material.OAK_WALL_SIGN))) return;
	    Sign sign = (Sign) e.getClickedBlock().getState();
	    String[] line = sign.getLines();
	    Player p = e.getPlayer();
	    String owner = line[2].toLowerCase();
	    owner = ChatColor.stripColor(owner);
	    p.sendMessage(owner);
	    if(owner.contains(p.getName())) {
	    	if(!(line[0].contains(""))) return;
	    	gui = Bukkit.createInventory(null, InventoryType.HOPPER, (ChatColor.translateAlternateColorCodes('&', "&f Your Cell")));	
	    	ItemStack i = (new ItemStack(Material.IRON_BARS));
	    	ItemMeta meta = i.getItemMeta();
	    	meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&aAdd a Player"));
	    	List<String> lore = new ArrayList<String>();
	    	String celln = line[1];
	    	celln = ChatColor.stripColor(celln);
	    	lore.add(celln);
	    	meta.setLore(lore);
	    	i.setItemMeta(meta);
	    	gui.setItem(0, i);
	    	meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&cRemove a Player"));
	    	meta.setLore(lore);
	    	i.setItemMeta(meta);
	    	gui.setItem(1, i);
	    	meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&cAbandon your Cell"));
	    	meta.setLore(lore);
	    	i.setItemMeta(meta);
	    	gui.setItem(2, i);
	    	meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&cSet your cell's description"));
	    	meta.setLore(lore);
	    	i.setItemMeta(meta);
	    	gui.setItem(3, i);
	    	p.openInventory(gui);
	    } else if (owner.contains("unowned")) {
	    	if(!(line[0].toLowerCase().equalsIgnoreCase(""))) return;
    		Integer max = 1;
    		Integer amount = 0;
	    	if (eco.getBalance(p) > 4999) {
	    		if (p.hasPermission("vip")) max = 2;
	    		List<Location> cells = plugin.cells;
	    		Iterator<Location> cell = cells.iterator();
	    		while (cell.hasNext()) {
	    			Location s = cell.next();
	    			Block b = s.getBlock();
	    			Sign sign1 = (Sign) b.getState();
	    			String[] line1 = sign1.getLines();
	    			String owner2 = line1[2].toLowerCase();
	    			owner2 = ChatColor.stripColor(owner2);
	    			if(owner2.contains("" + p.getName())) amount++;
	    		} 
	    		if (!(amount > max - 1)) {
					eco.withdrawPlayer(p, "", 5000);   
					sign.setLine(2, (ChatColor.translateAlternateColorCodes('&', "&a" + p.getName())));
					sign.update();
			    	String celln = line[1];
			    	celln = ChatColor.stripColor(celln);
			    	Integer celln2 = Integer.parseInt(celln);
					plugin.cell.put(p, celln2);
					Bukkit.dispatchCommand(Bukkit.getServer().getConsoleSender(), "lp user " + p.getName() + " permission set worldguard.*");
					Bukkit.dispatchCommand(p, "rg addmember cell" + celln + " " + p.getName());
					Bukkit.dispatchCommand(p, "rg flag cell" + celln + " block-break -g members allow");
					Bukkit.dispatchCommand(p, "rg flag cell" + celln + " block-place -g members allow");
					Bukkit.dispatchCommand(p, "rg flag cell" + celln + " chest-access -g trial allow");
					Bukkit.dispatchCommand(p, "rg flag cell" + celln + " block-place -g trial allow");
					Bukkit.dispatchCommand(p, "rg flag cell" + celln + " block-break -g trial allow");
					Bukkit.dispatchCommand(p, "rg flag cell" + celln + " chest-access -g members allow");
					Bukkit.dispatchCommand(p, "rg setpriority " + celln + " 1000");
					Bukkit.dispatchCommand(Bukkit.getServer().getConsoleSender(), "lp user " + p.getName() + " permission unset worldguard.*");
		    		p.sendMessage((ChatColor.translateAlternateColorCodes('&',"&c&l WARNING:&f You now own a cell. Please note that being offline for 7 days or more makes you eligible for cell deletion. Your items stored in your cell will be saved, but you will be removed from it. Contact a General or above to keep it safe for a set date. &cWe do not preserve cells for more than 2 weeks.&f If you become a fugitive, your cell will be deleted too. You can store contraband here, but if caught acting suspicious, it will be searched."))); 

	    		} else {
		    		p.sendMessage((ChatColor.translateAlternateColorCodes('&',"&c You have the max amount of cells you're allowed to have. " + amount + "/" + max + " Check /buy for more cells!"))); 
		    		return;
	    		} 	
	    	} else {
	    		p.sendMessage((ChatColor.translateAlternateColorCodes('&',"&c You need at least $5000 to buy a cell!"))); 
	    		return;
	    		
	    	}
	    }
		
	    
	  }
	
	@EventHandler
	public void cellclick(InventoryClickEvent e) {
		if (!(e.getView().getTitle().equalsIgnoreCase(ChatColor.translateAlternateColorCodes('&', "&f Your Cell")))) return;
		e.setCancelled(true);	
		Player p = (Player) e.getWhoClicked();
		switch(e.getSlot()) {
			case 0: {
				String celln = e.getCurrentItem().getItemMeta().getLore().get(0);
			    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_FLUTE, 1, 2);
				gui = Bukkit.createInventory(null, 45, (ChatColor.translateAlternateColorCodes('&', "&f Add a Player")));
				ItemStack skull = new ItemStack(Material.PLAYER_HEAD, 1);
		        SkullMeta meta = (SkullMeta) skull.getItemMeta();
		        Integer slot = 0;
				for (Player players : Bukkit.getOnlinePlayers()) {
			        meta.setOwner(players.getName());
					List<String> lore = new ArrayList<String>();
					lore.add(celln);
					meta.setLore(lore);
					meta.setDisplayName("" + players.getName());
			        skull.setItemMeta(meta);
					gui.setItem(slot, skull);
					slot++;
					
				}
				p.openInventory(gui);
				break;
			}
			case 1: {
				String celln = e.getCurrentItem().getItemMeta().getLore().get(0);
			    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_FLUTE, 1, 2);
				gui = Bukkit.createInventory(null, 45, (ChatColor.translateAlternateColorCodes('&', "&f Remove a Player")));
				ItemStack skull = new ItemStack(Material.PLAYER_HEAD, 1);
		        SkullMeta meta = (SkullMeta) skull.getItemMeta();
		        Integer slot = 0;
				for (Player players : Bukkit.getOnlinePlayers()) {
			        meta.setOwner(players.getName());
					List<String> lore = new ArrayList<String>();
					lore.add(celln);
					meta.setLore(lore);
					meta.setDisplayName("" + players.getName());
			        skull.setItemMeta(meta);
					gui.setItem(slot, skull);
					slot++;
					
				}
				p.openInventory(gui);
				break;
			}

			case 2: {
				String celln = e.getCurrentItem().getItemMeta().getLore().get(0);
			    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_FLUTE, 1, 2);
				gui = Bukkit.createInventory(null, InventoryType.HOPPER, (ChatColor.translateAlternateColorCodes('&', "&f Abandon your Cell?")));
		    	ItemStack i = (new ItemStack(Material.GREEN_WOOL));
		    	ItemMeta meta = i.getItemMeta();
		    	meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&aYes"));
		    	List<String> lore = new ArrayList<String>();
		    	celln = ChatColor.stripColor(celln);
		    	lore.add(celln);
		    	meta.setLore(lore);
		    	i.setItemMeta(meta);
		    	gui.setItem(0, i);
		    	ItemStack i2 = (new ItemStack(Material.RED_WOOL));
		    	ItemMeta meta2 = i2.getItemMeta();
		    	meta2.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&cNO"));
		    	lore.add(celln);
		    	meta2.setLore(lore);
		    	i2.setItemMeta(meta2);
		    	gui.setItem(4, i2);
					
				p.openInventory(gui);
			}
			case 3:
			    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1, 2);
	    		p.sendMessage((ChatColor.translateAlternateColorCodes('&',"&f To set your cell's description, do /celldesc <Text> while looking at your cell's sign!"))); 
				break;	
				
		}
		
	}
	@EventHandler
	public void addplr(InventoryClickEvent e) {
		if (!(e.getView().getTitle().contains(ChatColor.translateAlternateColorCodes('&', "&f")))) return;
		e.setCancelled(true);	
		Player p = (Player) e.getWhoClicked();
		Player player = Bukkit.getPlayer(e.getCurrentItem().getItemMeta().getDisplayName());
		Bukkit.dispatchCommand(Bukkit.getServer().getConsoleSender(), "op" + p);
		String celln = e.getCurrentItem().getItemMeta().getLore().get(0);
		if (e.getView().getTitle().equalsIgnoreCase(ChatColor.translateAlternateColorCodes('&', "&f Add a Player"))) Bukkit.dispatchCommand(p, "rg addmember cell" + celln + " " + player.getName());
		if (e.getView().getTitle().equalsIgnoreCase(ChatColor.translateAlternateColorCodes('&', "&f Remove a Player"))) Bukkit.dispatchCommand(p, "rg removemember cell" + celln + " " + player.getName());
		
	}
	@EventHandler
	public void confirm(InventoryClickEvent e) {
		if (!(e.getView().getTitle().equalsIgnoreCase(ChatColor.translateAlternateColorCodes('&', "&f Abandon your Cell?")))) return;
		e.setCancelled(true);	
		Player p = (Player) e.getWhoClicked();
		Bukkit.dispatchCommand(Bukkit.getServer().getConsoleSender(), "op" + p);
		String celln = e.getCurrentItem().getItemMeta().getLore().get(0);
		if (e.getCurrentItem().getType() == Material.GREEN_WOOL) {
			Bukkit.dispatchCommand(Bukkit.getServer().getConsoleSender(), "op " + p);
			Bukkit.dispatchCommand(p, "rg removemember cell" + celln + " -a");
			Bukkit.dispatchCommand(p, "removecell " + celln);
		}
		if (e.getCurrentItem().getType() == Material.RED_WOOL) p.closeInventory();
		
	}


	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (!(sender instanceof Player)) return false;
		if (label.equalsIgnoreCase("cellslist")) {
			Player p = (Player) sender;
			p.sendMessage("cell list: " + plugin.cells);
			return false;
		}
		else if (label.equalsIgnoreCase("clearcells")) {
			plugin.cells.clear();
			FileConfiguration config = this.plugin.getConfig();
			config.set("cells", null);
			plugin.saveConfig(); 		
			return false;

		}
		else if (label.equalsIgnoreCase("removecell")) {
    		List<Location> cells = plugin.cells;
    		Iterator<Location> cell = cells.iterator();
    		while (cell.hasNext()) {
    			Location s = cell.next();
    			Block b = s.getBlock();
    			Sign sign1 = (Sign) b.getState();
    			String[] line1 = sign1.getLines();
    			String celln = line1[1];
    	    	celln = ChatColor.stripColor(celln);
    	    	Bukkit.broadcastMessage("args: " + args[0] + " cellN: " + celln);
    			if (args[0].equalsIgnoreCase(celln)) {
    				sign1.setLine(2, (ChatColor.translateAlternateColorCodes('&', "&f&lUnowned")));
    				sign1.update();
    				break;
    			}
    		} 	
			return false;

		}
		return false;

   }
}
